def suma (x,y):
    resultado = x + y
    return resultado 